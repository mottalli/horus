#!/bin/bash
#
#
#  gstreamer.sh
#
#  Usage:  gstreamer.sh
#
#-----------------------------------------------------------------------------
declare -i i0
declare -i i1

PROG=`which gst-launch`
if [ "x" = "x${PROG}" ]; then
  echo "Cannot find gst-launch.  Is it installed?"
  exit 1
fi
if [ ! -x ${PROG} ]; then
  echo "Cannot execute gst-launch.  Is it installed?"
  exit 1
fi
#-----------------------------------------------------------------------------
ls /dev/easy* /dev/video* /proc/asound/* >/dev/null 2>/dev/null
DEV_VIDEO=""
DEV_AUDIO=""
i0=0;
while [ -z ${DEV_VIDEO} ]; do
  if [ -c "/dev/easycap${i0}" ]; then
    DEV_VIDEO="/dev/easycap${i0}"; break
  fi
  if [ -h "/dev/easycap${i0}" ]; then
    DEV_VIDEO="/dev/easycap${i0}"; break
  fi
  if [ 8 -eq ${i0} ]; then DEV_VIDEO="NONE"; fi
  i0=$i0+1
done
if [ "NONE" = "${DEV_VIDEO}" ]; then DEV_VIDEO=""; fi
#-----------------------------------------------------------------------------
#  REMOVE THE FOLLOWING SECTION TO PREVENT THIS SCRIPT FROM LOOKING FOR
#  /dev/video* WHENEVER /dev/easycap* CANNOT BE FOUND.
#=============================================================================
i1=0;
while [ -z ${DEV_VIDEO} ]; do
  if [ -c "/dev/video${i1}" ]; then
    DEV_VIDEO="/dev/video${i1}"; i0=${i1}; break
  fi
  if [ 8 -eq ${i1} ]; then DEV_VIDEO="NONE"; fi
  i1=$i1+1
done
if [ "NONE" = "${DEV_VIDEO}" ]; then DEV_VIDEO=""; fi
#=============================================================================
if [ -z ${DEV_VIDEO} ]; then
  echo "Cannot find /dev/easycap*, /dev/video*"
  exit 1
fi
#-----------------------------------------------------------------------------
if [ -z "`ls -1 /proc/asound`" ]; then
  echo "ERROR: empty /proc/asound"
  exit 1
fi
link=`ls -lart /proc/asound | grep "EasyALSA${i0}" - `
if [ -z "${link}" ]; then
  echo "ERROR: missing /proc/asound/EasyALSA${i0}"
  exit 1
fi
hwnr=`echo ${link} | sed -e "s,^.*-> ,,;s,card,," `
card=/proc/asound/`echo ${link} | sed -e "s,^.*-> ,," `
if [ ! -d "${card}" ]; then
  echo "ERROR: absent or bad card:  ${card}"
  exit 1
fi
if [ ! -d "${card}/pcm0c" ]; then
  echo "ERROR: absent or bad pcm: ${card}/pcm0c"
  exit 1
fi
if [ -z "${hwnr}" ]; then
  echo "ERROR: absent or bad card number: ${hwnr}"
  exit 1
fi
DEV_AUDIO="${hwnr},0"
#-----------------------------------------------------------------------------
LOG="./gstreamer.log"
ERR="./gstreamer.err"

echo "Devices are:  ${DEV_VIDEO}  plughw:${DEV_AUDIO}"
echo "Log files are:   ${LOG}  ${ERR}"

GST_DEBUG=v4l2src*:5 1>${LOG} 2>${ERR} \
gst-launch v4l2src device=${DEV_VIDEO} ! xvimagesink
#gst-launch alsasrc device=plughw:${DEV_AUDIO} ! alsasink

exit 0
