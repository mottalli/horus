#!/bin/bash
#
#  frequency.sh
#
#
#  Usage:  ./frequency.sh
#
#  Requires that precisely one EasyCAP is plugged in.
#
#-----------------------------------------------------------------------------

MANY=`2>/dev/null lsusb -v -d 05e1:0408 | grep tSamFreq | wc -l `
if [ "x" = "x${MANY}" ]; then
  echo "ERROR:  cannot count 05e1:0408 EasyCAPs"
  exit 1
fi
if [ "0" = "${MANY}" ]; then
  echo "ERROR:  No 05e1:0408 EasyCAP found. Is it plugged in? Is it a Syntek?"
  exit 1
fi
if [ "1" != "${MANY}" ]; then
  echo "ERROR:  Too many 05e1:0408 EasyCAPs found:  one at a time, please"
  exit 1
fi
FREQ=""
FREQ=`2>/dev/null lsusb -v -d 05e1:0408 | grep tSamFreq | sed -e "s,^.* ,,"`
if [ "x${FREQ}" = "x8000" ]; then FREQ=32000; fi
if [ "x${FREQ}" = "x48000" ]; then FREQ=48000; fi
if [ "x" = "x${FREQ}" ]; then
  echo "ERROR:  could not identify audio frequency"
  exit 1
fi
echo "Audio frequency is ${FREQ} Hz"
exit 0
