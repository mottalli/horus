#!/bin/bash
#
#  permit.sh
#
#  It is necessary to use this script only if the installation has not
#  been fully successful.  Reinstallation of the driver is recommended.
#
#-----------------------------------------------------------------------------
#if [ -c /dev/video0 ]; then chmod ugo+rw /dev/video* ; fi
if [ -c /dev/easycap0 ]; then chmod ugo+rw /dev/easycap* ; fi
if [ -c /dev/easycap1 ]; then chmod ugo+rw /dev/easycap* ; fi
if [ -c /dev/easycap2 ]; then chmod ugo+rw /dev/easycap* ; fi
if [ -c /dev/easyoss0 ]; then chmod ugo+rw /dev/easyoss* ; fi
if [ -c /dev/easyoss1 ]; then chmod ugo+rw /dev/easyoss* ; fi
if [ -c /dev/easyoss2 ]; then chmod ugo+rw /dev/easyoss* ; fi
if [ -c /dev/dsp ]; then chmod ugo+rw /dev/dsp ; fi

