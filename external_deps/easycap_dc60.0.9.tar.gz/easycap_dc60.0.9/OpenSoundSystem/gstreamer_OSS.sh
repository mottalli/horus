#!/bin/bash
#
#
#  gstreamer.sh
#
#  Usage:  gstreamer.sh
#
#-----------------------------------------------------------------------------
declare -i i0

PROG=`which gst-launch`
if [ "x" = "x${PROG}" ]; then
  echo "Cannot find gstreamer.  Is it installed?"
  exit 1
fi
if [ ! -x ${PROG} ]; then
  echo "Cannot execute gst-launch.  Is it installed?"
  exit 1
fi
#-----------------------------------------------------------------------------
ls /dev/easy* /dev/video* >/dev/null 2>/dev/null
DEV_VIDEO=""
DEV_AUDIO=""
i0=0;
while [ -z ${DEV_VIDEO} ]; do
  if [ -c "/dev/easycap${i0}" ]; then DEV_VIDEO="/dev/easycap${i0}"; fi
  if [ 8 -eq ${i0} ]; then DEV_VIDEO="NONE"; fi
  i0=$i0+1
done
if [ "NONE" = "${DEV_VIDEO}" ]; then DEV_VIDEO=""; fi
#-----------------------------------------------------------------------------
#  REMOVE THE FOLLOWING SECTION TO PREVENT THIS SCRIPT FROM LOOKING FOR
#  /dev/video* WHENEVER /dev/easycap* CANNOT BE FOUND.
#=============================================================================
i0=0;
while [ -z ${DEV_VIDEO} ]; do
  if [ -c "/dev/video${i0}" ]; then DEV_VIDEO="/dev/video${i0}"; fi
  if [ 8 -eq ${i0} ]; then DEV_VIDEO="NONE"; fi
  i0=$i0+1
done
if [ "NONE" = "${DEV_VIDEO}" ]; then DEV_VIDEO=""; fi
#=============================================================================
if [ -z ${DEV_VIDEO} ]; then
  echo "Cannot find /dev/easycap*, /dev/video*"
  exit 1
fi
#-----------------------------------------------------------------------------
i0=0;
while [ -z ${DEV_AUDIO} ]; do
  if [ -c "/dev/easyoss${i0}" ]; then DEV_AUDIO="/dev/easyoss${i0}"; fi
  if [ 8 -eq ${i0} ]; then DEV_AUDIO="NONE"; fi
  i0=$i0+1
done
if [ "NONE" = "${DEV_AUDIO}" ]; then DEV_AUDIO=""; fi

if [ -z ${DEV_AUDIO} ]; then
  echo "Cannot find /dev/easyoss*"
  exit 1
fi
#-----------------------------------------------------------------------------
LOG="./gstreamer.log"
ERR="./gstreamer.err"

echo "Devices are:  ${DEV_VIDEO}  ${DEV_AUDIO}"
echo "Log files are:   ${LOG}  ${ERR}"

GST_DEBUG=v4l2src*:5 1>${LOG} 2>${ERR} \
gst-launch v4l2src device=${DEV_VIDEO} ! xvimagesink

exit 0
