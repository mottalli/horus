#!/bin/bash
#
#
#  checktestPAL_OSS.sh
#
#  Usage:  ./checktestPAL_OSS.sh
#
#
#  Must be run from within subdirectory tools
#
#
#-----------------------------------------------------------------------------

SUBDIR=`pwd | sed -e "s,^.*/,,"`
if [ ".tools" != ".${SUBDIR}" ]; then
  echo "ERROR:  must be run from within subdirectory tools"
  exit 1
fi
cd ..
if [ ! -e "./src/easycap.h" ]; then
  echo "ERROR:  wrong directory"
  exit 1
fi
if [ ! -e "./OpenSoundSystem/testPAL_OSS.sh" ]; then
  echo "ERROR:  missing file ./OpenSoundSystem/testPAL_OSS.sh"
  exit 1
fi
#-----------------------------------------------------------------------------

cat ./OpenSoundSystem/testPAL_OSS.sh | sed \
                      "s,-msglevel all=9,-frames 200 -msglevel all=9," > \
                                                   ./tools/checktesttmp.sh
chmod +x ./tools/checktesttmp.sh

for i in  1 10  2 11  3 12  4 13  3 14  2 15  1 16 \
          5 17  6 19  7 17  8 16  9 15 18 14  9 13  8 12  7 11  6 10  5
do
  echo "test $i begins"
  ./tools/checktesttmp.sh $i
  echo "test $i ends"
  sleep 2
done

#==== SOUND ONLY ====
i=64
echo "test $i begins"
./OpenSoundSystem/testPAL_OSS.sh $i
echo "test $i ends"

rm ./tools/checktesttmp.sh
exit 0

