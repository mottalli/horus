#!/bin/bash
#
#
#  checktestNTSC.sh
#
#  Usage:  ./checktestNTSC.sh
#
#
#  Must be run from within subdirectory tools
#
#
#-----------------------------------------------------------------------------

SUBDIR=`pwd | sed -e "s,^.*/,,"`
if [ ".tools" != ".${SUBDIR}" ]; then
  echo "ERROR:  must be run from within subdirectory tools"
  exit 1
fi
cd ..
if [ ! -e "./src/easycap.h" ]; then
  echo "ERROR:  wrong directory"
  exit 1
fi
if [ ! -e "./testNTSC.sh" ]; then
  echo "ERROR:  missing file ./testNTSC.sh"
  exit 1
fi
#-----------------------------------------------------------------------------

cat ./testNTSC.sh | sed "s,-msglevel all=9,-frames 200 -msglevel all=9," > \
                                                   ./tools/checktesttmp.sh
chmod +x ./tools/checktesttmp.sh

for i in  1   9  2 10  3 11  2 12 1 13           \
          4  14  5 15  6 16  7 18 8 16 17 15  8 14  7 13  6 12  5 11  4 10
do
  echo "test $i begins"
  ./tools/checktesttmp.sh $i
  echo "test $i ends"
  sleep 2
done

#==== SOUND ONLY ====
i=64
echo "test $i begins"
./testNTSC.sh $i
echo "test $i ends"

rm ./tools/checktesttmp.sh
exit 0

