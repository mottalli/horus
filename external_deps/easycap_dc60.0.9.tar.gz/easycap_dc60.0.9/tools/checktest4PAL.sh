#!/bin/bash
#
#
#  checktest4PAL.sh
#
#  Usage:  ./checktest4PAL.sh
#
#
#
#  Must be run from within subdirectory tools
#
#-----------------------------------------------------------------------------

SUBDIR=`pwd | sed -e "s,^.*/,,"`
if [ ".tools" != ".${SUBDIR}" ]; then
  echo "ERROR:  must be run from within subdirectory tools"
  exit 1
fi
cd ..
if [ ! -e "./src/easycap.h" ]; then
  echo "ERROR:  wrong directory.sh"
  exit 1
fi
if [ ! -e "./test4PAL.sh" ]; then
  echo "ERROR:  missing file ./test4PAL.sh"
  exit 1
fi
#-----------------------------------------------------------------------------

cat test4PAL.sh | sed "s,-msglevel all=9,-frames 200 -msglevel all=9," > \
                                                    ./tools/checktesttmp.sh
chmod +x ./tools/checktesttmp.sh

for i in  1 10  2 11  3 12  4 13  5 14  6 15  7 16  8 17  9 19 \
         18 17  9 16  8 15  7 14  6 13  5 12  4 11  3 10  2 19  1
do
  echo "test $i begins"
  ./tools/checktesttmp.sh $i
  echo "test $i ends"
  sleep 2
done
#==== SOUND ONLY ====
i=65
echo "test $i begins"
./test4PAL.sh $i
echo "test $i ends"

rm ./tools/checktesttmp.sh
exit 0

