#!/bin/bash
#
#
#  checktest4NTSC.sh
#
#  Usage:  ./checktest4NTSC.sh
#
#
#
#  Must be run from within subdirectory tools
#
#-----------------------------------------------------------------------------

SUBDIR=`pwd | sed -e "s,^.*/,,"`
if [ ".tools" != ".${SUBDIR}" ]; then
  echo "ERROR:  must be run from within subdirectory tools"
  exit 1
fi
cd ..
if [ ! -e "./src/easycap.h" ]; then
  echo "ERROR:  wrong directory.sh"
  exit 1
fi
if [ ! -e "./test4NTSC.sh" ]; then
  echo "ERROR:  missing file ./test4NTSC.sh"
  exit 1
fi
#-----------------------------------------------------------------------------

cat test4NTSC.sh | sed "s,-msglevel all=9,-frames 200 -msglevel all=9," > \
                                                    ./tools/checktesttmp.sh
chmod +x ./tools/checktesttmp.sh

for i in  1  9  2 10  3 11  4 12  5 13  6 14  7 15  8 16  17 18 \
          8 16  7 15  6 14  5 13  4 12  3 11  2 10  1  9
do
  echo "test $i begins"
  ./tools/checktesttmp.sh $i
  echo "test $i ends"
  sleep 2
done

#==== SOUND ONLY ====
i=65
echo "test $i begins"
./test4NTSC.sh $i
echo "test $i ends"

rm ./tools/checktesttmp.sh
exit 0

