#!/bin/bash
#
#
#  patolerate.sh
#
#
#  Usage:  ./patolerate.sh  yes           ENABLE  PulseAudio
#          ./patolerate.sh  no           DISABLE  PulseAudio
#
#
#  This implements the procedure described by Carla Schroder at
#         http://www.linuxplanet.com/linuxplanet/tutorials/7130/1/
#  I have tested it systematically only on Ubuntu (for which it was
#  originally intended), but it may work for other distributions as well.
#  Handle with care:  Linux audio is fragile.
#
#------------------------------------------------------------------------------
if [ "xroot" != "x`whoami`" ]; then
  echo "ERROR:  must be run as root"
  echo "        On Ubuntu, try: sudo ./patolerate.sh"
  exit 1
fi
if [ "x" = "x$1" ]; then
  echo "Usage:  ./patolerate  yes|no"
  exit 1
fi
if [ "x" != "x$2" ]; then
  echo "Usage:  ./patolerate  yes|no"
  exit 1
fi
action=""
if [ "xyes" = "x$1" ]; then action="start"; fi
if [ "xYes" = "x$1" ]; then action="start"; fi
if [ "xYES" = "x$1" ]; then action="start"; fi
if [ "xno" = "x$1" ]; then action="kill"; fi
if [ "xNo" = "x$1" ]; then action="kill"; fi
if [ "xNO" = "x$1" ]; then action="kill"; fi
if [ "x${action}" = "x" ]; then
  echo "Usage:  ./patolerate  yes|no"
  exit 1
fi
#------------------------------------------------------------------------------
daemon=`ps -A | grep -i pulseaudio -`
if [ "x" = "x${daemon}" ]; then
  if [ "kill" = ${action} ]; then
    echo "PulseAudio daemon is not running: nothing needs to be done"
    exit 0
  fi
else
  if [ "start" = ${action} ]; then
    echo "PulseAudio daemon already running: nothing needs to be done"
    exit 0
  fi
fi
#------------------------------------------------------------------------------
if [ ! -d "/etc/init.d" ]; then
  echo "ERROR:  cannot find directory /etc/init.d"
  exit 1
fi
PASCRIPT="/etc/init.d/pulseaudio"
if [ ! -x "${PASCRIPT}" ]; then
  PASCRIPT=""
fi
if [ ! -d "/etc/pulse" ]; then
  echo "ERROR:  cannot find directory /etc/pulse"
  echo "        Is PulseAudio installed at all?"
  exit 1
fi
CLIENTCONF="/etc/pulse/client.conf"
if [ ! -e "${CLIENTCONF}" ]; then
  echo "ERROR:  cannot find file ${CLIENTCONF}"
  exit 1
fi
#-----------------------------------------------------------------------------
RCD="/etc/rc2.d"
S50PULSEAUDIO=""
K50PULSEAUDIO=""
if [ ! -d "${RCD}" ]; then
  RCD=""
else
  many=`find ${RCD} -name "*pulseaudio" -print | wc -l`
  if [ "x0" = "x${many}" ]; then
    echo "ERROR: cannot find ${RCD}/...*pulseaudio"
    exit 1
  fi
  if [ "x1" != "x${many}" ]; then
    echo "ERROR: too many files ${RCD}/...*pulseaudio"
    exit 1
  fi
  RCDPULSEAUDIO=`find ${RCD} -name "*pulseaudio" -print`
  if [ -z "${RCDPULSEAUDIO}" ]; then
    echo "MISTAKE:  RCDPULSEAUDIO is empty"
    exit 2
  fi
  file=`echo ${RCDPULSEAUDIO} | sed -e "s,^.*/,," - `
  subd=`echo ${RCDPULSEAUDIO} | sed -e "s,/\${file}$,," - `
  if [ "${RCDPULSEAUDIO}" != "${subd}/${file}" ];  then
    echo "MISTAKE:  ${RCDPULSEAUDIO} not ${subd}/${file}"
    exit 2
  fi
  kors=`echo ${RCDPULSEAUDIO} | sed -e "s,[0-9]*pulseaudio$,,;s,^.*/,," - `
  if [ \( "xK" != "x${kors}" \) -a \( "xS" != "x${kors}" \) ]; then
    echo "ERROR: cannot find ${RCD}/...S*pulseaudio or ${RCD}...K*pulseaudio"
    exit 1
  fi
  if [ "xK" = "x${kors}" ]; then
    K50PULSEAUDIO="${RCDPULSEAUDIO}"
    S50PULSEAUDIO="${subd}/`echo ${file} | sed -e "s,^K,S," - `"
  fi
  if [ "xS" = "x${kors}" ]; then
    S50PULSEAUDIO="${RCDPULSEAUDIO}"
    K50PULSEAUDIO="${subd}/`echo ${file} | sed -e "s,^S,K," - `"
  fi
  if [ \( -z "${K50PULSEAUDIO}" \) -o \( -z "${S50PULSEAUDIO}" \) ]; then
    echo "MISTAKE:  K50PULSEAUDIO or S50PULSEAUDIO is empty"
    exit 2
  fi
  if [ \( ! -e "${K50PULSEAUDIO}" \) -a \( ! -e "${S50PULSEAUDIO}" \) ]; then
    echo "ERROR:  neither K50PULSEAUDIO nor S50PULSEAUDIO exists"
    exit 1
  fi
fi
#------------------------------------------------------------------------------
XSESSIOND="/etc/X11/Xsession.d"
if [ -d "${XSESSIOND}" ]; then
  if [ "x" != "x`find ${XSESSIOND} -name \"*pulseaudio\" -print`" ]; then
    echo "ERROR:  PulseAudio file in directory ${XSESSIOND} or subdirectory"
    exit 1
  fi
fi
if [ "start" = "${action}" ]; then
#=============================================================================
  echo "Proposing to:"
  echo "  edit two lines in file ${CLIENTCONF}"
  if [ ! -z ${RCD} ]; then
    if [ -e ${K50PULSEAUDIO} ]; then
      echo "  rename file ${K50PULSEAUDIO} to ${S50PULSEAUDIO}"
    else
      echo "  retain file ${S50PULSEAUDIO}"
    fi
  fi
  echo "  start PulseAudio"
  echo -n "Proceed [y/n]? "
  goon=""
  while [ -z "${goon}" ];
  do
    read reply rump
    if [ \( "xy" = "x${reply}" \) -o \( "xY" = "x${reply}" \) ]; then
      goon=y;
    fi
    if [ \( "xn" = "x${reply}" \) -o \( "xN" = "x${reply}" \) ]; then
      goon=n;
    fi
    if [ -z "${goon}" ]; then
      echo -n "Proceed [y/n]? "
    fi
  done
  if [ "xn" = "x${goon}" ]; then
    echo "Nothing done"
    exit 0
  fi
#------------------------------------------------------------------------------
#  STARTING PulseAudio
#------------------------------------------------------------------------------
  sed -i -e "s,^[ \t]*autospawn[ \t]*no.*,\; autospawn yes," ${CLIENTCONF}
  sed -i -e "s,^[ \t]*daemon-binary[ \t]*=[ \t]*/bin/true.*,\; daemon-binary = /usr/bin/pulseaudio," ${CLIENTCONF}
  if [ ! -z ${RCD} ]; then
    if [ -e "${K50PULSEAUDIO}" ]; then
      mv ${K50PULSEAUDIO} ${S50PULSEAUDIO}
    fi
    if [ -x ${PASCRIPT} ]; then
      ${PASCRIPT} --start
    fi
  fi
  daemon=`ps -A | grep -i pulseaudio -`
  if [ "x" = "x${daemon}" ]; then
    notroot=""
    cd && notroot=`pwd | sed -e "s,^.*/,," - `
    if [ "xroot" = "x${notroot}" ]; then
      echo "Please start PulseAudio manually, not as root, with the command:"
      echo "pulseaudio --daemonize"
      exit 0
    fi
    if [ ! -z ${notroot} ]; then
      echo "Starting PulseAudio as user '${notroot}'"
      su -c "pulseaudio --daemonize" ${notroot}
    fi
  fi
else
#=============================================================================
  echo "Proposing to:"
  echo "  edit two lines in file ${CLIENTCONF}"
  if [ ! -z ${RCD} ]; then
    if [ -e ${S50PULSEAUDIO} ]; then
      echo "  rename file ${S50PULSEAUDIO} to ${K50PULSEAUDIO}"
    else
      echo "  retain file ${K50PULSEAUDIO}"
    fi
  fi
  echo "  stop PulseAudio"
  echo -n "Proceed [y/n]? "
  goon=""
  while [ -z "${goon}" ];
  do
    read reply rump
    if [ \( "xy" = "x${reply}" \) -o \( "xY" = "x${reply}" \) ]; then
      goon=y;
    fi
    if [ \( "xn" = "x${reply}" \) -o \( "xN" = "x${reply}" \) ]; then
      goon=n;
    fi
    if [ -z "${goon}" ]; then
      echo -n "Proceed [y/n]? "
    fi
  done
  if [ "xn" = "x${goon}" ]; then
    echo "Nothing done"
    exit 0
  fi
#------------------------------------------------------------------------------
#  STOPPING PulseAudio
#------------------------------------------------------------------------------
  sed -i -e "s,^[ \t]*\;*[ \t]*autospawn[ \t]*yes.*,\autospawn no," ${CLIENTCONF}
  sed -i -e "s,^[ \t]*\;*[ \t]*daemon-binary[ \t]*=[ \t]*/usr/bin/pulseaudio.*,daemon-binary = /bin/true," ${CLIENTCONF}
  if [ ! -z ${RCD} ]; then
    if [ -e "${S50PULSEAUDIO}" ]; then
      mv ${S50PULSEAUDIO} ${K50PULSEAUDIO}
    fi
    if [ -x ${PASCRIPT} ]; then
      ${PASCRIPT} --kill
    fi
  fi
  daemon=`ps -A | grep -i pulseaudio -`
  if [ "x" != "x${daemon}" ]; then
    killall pulseaudio
  fi
fi
echo "All done"
exit 0

