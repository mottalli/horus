#!/bin/bash
#
#
#  checktest4PAL_OSS.sh
#
#  Usage:  ./checktest4PAL_OSS.sh
#
#
#
#  Must be run from within subdirectory tools
#
#-----------------------------------------------------------------------------

SUBDIR=`pwd | sed -e "s,^.*/,,"`
if [ ".tools" != ".${SUBDIR}" ]; then
  echo "ERROR:  must be run from within subdirectory tools"
  exit 1
fi
cd ..
if [ ! -e "./src/easycap.h" ]; then
  echo "ERROR:  wrong directory.sh"
  exit 1
fi
if [ ! -e "./OpenSoundSystem/test4PAL_OSS.sh" ]; then
  echo "ERROR:  missing file ./OpenSoundSystem/test4PAL_OSS.sh"
  exit 1
fi
#-----------------------------------------------------------------------------

cat ./OpenSoundSystem/test4PAL_OSS.sh | \
                      sed "s,-msglevel all=9,-frames 200 -msglevel all=9," > \
                                                    ./tools/checktesttmp.sh
chmod +x ./tools/checktesttmp.sh

for i in  1 10  2 11  3 12  4 13  5 14  6 15  7 16  8 17  9 19 \
         18 17  9 16  8 15  7 14  6 13  5 12  4 11  3 10  2 19  1
do
  echo "test $i begins"
  ./tools/checktesttmp.sh $i
  echo "test $i ends"
  sleep 2
done
#==== SOUND ONLY ====
i=65
echo "test $i begins"
./OpenSoundSystem/test4PAL_OSS.sh $i
echo "test $i ends"

rm ./tools/checktesttmp.sh
exit 0

