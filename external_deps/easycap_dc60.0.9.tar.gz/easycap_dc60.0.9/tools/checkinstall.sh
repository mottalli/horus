#!/bin/bash
#
#
#  checkinstall.sh
#
#  Usage:  ./checkinstall.sh
#          ./checkinstall.sh kerneldirectory
#
#  Must be run as root from within subdirectory tools
#
#-----------------------------------------------------------------------------
if [ "x" != "x$1" ]; then
  KERNELDIR="$1"
else
  KERNELDIR=""
fi

if [ "x`whoami`" != "xroot" ]; then
  echo "ERROR:  must be run as root"
  exit 1
fi

SUBDIR=`pwd | sed -e "s,^.*/,,"`
if [ ".tools" != ".${SUBDIR}" ]; then
  echo "ERROR:  must be run from within subdirectory tools"
  exit 1
fi
cd ..
if [ ! -e "./src/easycap.h" ]; then
  echo "ERROR:  wrong directory"
  exit 1
fi
if [ ! -e "./install.sh" ]; then
  echo "ERROR:  missing file ./install.sh"
  exit 1
fi
if [ ! -e "./install_simple.sh" ]; then
  echo "ERROR:  missing file ./install_simple.sh"
  exit 1
fi
#-----------------------------------------------------------------------------
echo "Running install_simple.sh"

./install_simple.sh

if [ 0 -ne $? ]; then
  echo "====FAILURE==="
  exit 1
fi
echo "======================== OK =========================="

#-----------------------------------------------------------------------------
echo "Running install.sh"

TD=`mktemp -d`

cat ./install.sh | sed -e "s,^DEBUG=[0-9]*,DEBUG=0,;s,^ALSA=[0-9]*,ALSA=0,;s,^CLIENT=[0-9]*,CLIENT=0,;s,^WFRAME=[0-9]*,WFRAME=0," >${TD}/install0.sh

for DEBUG in 0 9
do
  cat ${TD}/install0.sh | sed -e "s,^DEBUG=0,DEBUG=${DEBUG}," \
                                              >${TD}/install1.sh
  for CLIENT in 0 1
  do
    cat ${TD}/install1.sh | sed -e "s,^CLIENT=0,CLIENT=${CLIENT}," \
                                                   >${TD}/install2.sh
    for ALSA in 0 1
    do
      cat ${TD}/install2.sh | sed -e "s,^ALSA=0,ALSA=${ALSA}," \
                                               >${TD}/install4.sh
      for WFRAME in 0 1
      do
        cat ${TD}/install4.sh | sed -e "s,^WFRAME=0,WFRAME=${WFRAME}," \
                                                       >${TD}/install5.sh

        echo "------------------------------------------------------"
        grep "^DEBUG=" ${TD}/install5.sh
        grep "^CLIENT=" ${TD}/install5.sh
        grep "^ALSA=" ${TD}/install5.sh
        grep "^WFRAME=" ${TD}/install5.sh

         if [ -e "src/Makefile" ]; then rm src/Makefile; fi
         if [ -d "tmpsrc" ]; then rm -fR tmpsrc; fi

        chmod +x ${TD}/install5.sh

        ${TD}/install5.sh ${KERNELDIR}
        if [ 0 -ne $? ]; then
          echo "====FAILURE==="
          exit 1
        fi
        echo "======================== OK =========================="
      done
    done
  done
done

if [ -e "src/Makefile" ]; then rm src/Makefile; fi
if [ -d "tmpsrc" ]; then rm -fR tmpsrc; fi

if [ -z ${KERNELDIR} ]; then
  ./install.sh

  if [ 0 -ne $? ]; then
    echo "====FAILURE==="
    exit 1
  fi

  if [ -e "src/Makefile" ]; then rm src/Makefile; fi
  if [ -d "tmpsrc" ]; then rm -fR tmpsrc; fi
fi
echo "===================== ALL DONE ======================="

rm -fR ${TD}
exit 0
