#!/bin/bash
#
#
#  xawtvNTSC.sh
#
#
#  Usage:   ./xawtvNTSC.sh  [ NEW ]
#
#           If the literal string "NEW" is present,
#                    ${HOME}/.tvtime/tvtime.xml
#           is replaced by ./tvtime_NTSC.xml
#
#
#  This script assumes that the EasyCAP video output is available
#  either at     /dev/easycap*
#  or at         /dev/video*
#
#-----------------------------------------------------------------------------
#  If the installation procedure completed successfully this test should
#  work for an unprivileged user.  If necessary the script ./permit.sh can be
#  used to relax privileges.
#-----------------------------------------------------------------------------

declare -i rc
declare -i i0
declare -i i1

REFRESH=$1

standard="NTSC"

XAWTV=`which xawtv`
if [ "x" = "x${XAWTV}" ]; then
  echo "Cannot find xawtv.  Is it installed?"
  exit 1
fi
if [ ! -x ${XAWTV} ]; then
  echo "Cannot execute xawtv.  Is it installed?"
  exit 1
fi
if [ "x" = "x$HOME" ]; then
  echo "ERROR:  cannot find home directory"
  exit 1
fi

#-----------------------------------------------------------------------------
if [ \( ! -e "$HOME/.xawtv" \) -a \( ! -e "$HOME/.xawtvrc" \) ]; then
  echo "No existing file $HOME/.xawtv or $HOME/.xawtvrc"
  REFRESH="NEW"
fi
if [ "NEW" != "${REFRESH}" ]; then
  echo "Not overwriting existing file $HOME/.xawtv or $HOME/.xawtvrc"
  echo "To force a refresh, delete it/them or rename it/them."
  echo "For information on configuration syntax, run \`man xawtvrc\`"
  echo "... continuing ..."
else
  if [ -e ./xawtvrc_${standard} ]; then
    echo "Creating it from ./xawtvrc_${standard}"
    if [ -e "$HOME/.xawtvrc" ]; then rm $HOME/.xawtvrc; fi
    if [ -e "$HOME/.xawtv" ]; then rm $HOME/.xawtv; fi
    cp -p ./xawtvrc_${standard} $HOME/.xawtv
    if [ ! -e "$HOME/.xawtv" ]; then
      echo "ERROR: failed to create $HOME/.xawtv"
      exit 1
    fi
    ln -s $HOME/.xawtv $HOME/.xawtvrc
  else
    echo "ERROR: cannot find required file ./xawtvrc_${standard}"
    exit 1
  fi
fi
#-----------------------------------------------------------------------------
ls /dev/easy* /dev/video* /proc/asound/* >/dev/null 2>/dev/null
DEV_VIDEO=""
DEV_AUDIO=""
i0=0;
while [ -z ${DEV_VIDEO} ]; do
  if [ -c "/dev/easycap${i0}" ]; then
    DEV_VIDEO="/dev/easycap${i0}"; break
  fi
  if [ -h "/dev/easycap${i0}" ]; then
    DEV_VIDEO="/dev/easycap${i0}"; break
  fi
  if [ 8 -eq ${i0} ]; then DEV_VIDEO="NONE"; fi
  i0=$i0+1
done
if [ "NONE" = "${DEV_VIDEO}" ]; then DEV_VIDEO=""; fi
#-----------------------------------------------------------------------------
#  REMOVE THE FOLLOWING SECTION TO PREVENT THIS SCRIPT FROM LOOKING FOR
#  /dev/video* WHENEVER /dev/easycap* CANNOT BE FOUND.
#=============================================================================
i1=0;
while [ -z ${DEV_VIDEO} ]; do
  if [ -c "/dev/video${i1}" ]; then
    DEV_VIDEO="/dev/video${i1}"; i0=${i1}; break
  fi
  if [ 8 -eq ${i1} ]; then DEV_VIDEO="NONE"; fi
  i1=$i1+1
done
if [ "NONE" = "${DEV_VIDEO}" ]; then DEV_VIDEO=""; fi
#=============================================================================
if [ -z ${DEV_VIDEO} ]; then
  echo "Cannot find /dev/easycap*, /dev/video*"
  exit 1
fi
#-----------------------------------------------------------------------------
if [ -z "`ls -1 /proc/asound`" ]; then
  echo "ERROR: empty /proc/asound"
  exit 1
fi
link=`ls -lart /proc/asound | grep "EasyALSA${i0}" - `
if [ -z "${link}" ]; then
  echo "ERROR: missing /proc/asound/EasyALSA${i0}"
  exit 1
fi
hwnr=`echo ${link} | sed -e "s,^.*-> ,,;s,card,," `
card=/proc/asound/`echo ${link} | sed -e "s,^.*-> ,," `
if [ ! -d "${card}" ]; then
  echo "ERROR: absent or bad card:  ${card}"
  exit 1
fi
if [ ! -d "${card}/pcm0c" ]; then
  echo "ERROR: absent or bad pcm: ${card}/pcm0c"
  exit 1
fi
if [ -z "${hwnr}" ]; then
  echo "ERROR: absent or bad card number: ${hwnr}"
  exit 1
fi
DEV_AUDIO="${hwnr},0"
#-----------------------------------------------------------------------------

echo "Devices are:  ${DEV_VIDEO}  plughw:${DEV_AUDIO}"

#-----------------------------------------------------------------------------

${XAWTV} -c ${DEV_VIDEO} 2>xawtv.err

exit 0
