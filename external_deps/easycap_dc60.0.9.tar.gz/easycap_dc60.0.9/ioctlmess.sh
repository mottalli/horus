#!/bin/bash
#
#
#  ioctlmess.sh
#
#
#  This script is run automatically as part of driver installation.
#  It is not ordinarily necessary to run it manually.
#
#------------------------------------------------------------------------------
if [ "x`whoami`" != "xroot" ]; then
  echo "ERROR: script ./ioctlmess.sh must be run as root"
  exit 1
fi
if [ ! -e "./src/easycap_ioctl.c" ]; then
  echo "ERROR: script ./ioctlmess.sh running from wrong directory"
  exit 1
fi
#------------------------------------------------------------------------------
FNM="./src/easycap_ioctlmess.c"
if [ -e "${FNM}" ]; then rm ${FNM}; fi
HEADER1="/usr/src/linux-headers-`uname -r`/include/linux/videodev.h"
HEADER2="/usr/src/linux-headers-`uname -r`/include/linux/videodev2.h"
if [ -e ${HEADER1} ]; then H1="yes"; else H1="no"; fi
if [ -e ${HEADER2} ]; then H2="yes"; else H2="no"; fi

cat >${FNM} <<AAAAAAAA
/******************************************************************************
*                                                                             *
*  easycap_ioctlmess.c                                                        *
*                                                                             *
******************************************************************************/
/*
 *  THIS FILE IS WRITTEN AUTOMATICALLY BY SCRIPT $0
 *  DURING DRIVER INSTALLATION.  DO NOT EDIT WITHOUT GOOD REASON.
*/
/*---------------------------------------------------------------------------*/

#include "easycap.h"

struct mess { __u32 command; char  name[64]; };

int explain_ioctl( struct easycap *peasycap, __u32 wot )
{
int k;
static const struct mess mess[] =
{
AAAAAAAA

STR1="s,\n,,;h;s,^,#if defined(,;s,$,),;p;g;s/$/,\"/;"
STR2="G;s,\n,,;s,^,{,;s/$/\"},\n#endif/"

if [ "yes" = ${H2} ]; then

  cat ${HEADER2} | grep "^[ \t]*#define[ \t]*VIDIOC" - | \
     sed -e "s,[ \t]*#define[ \t]*,,;s,[ \t].*$,," - | \
     sed -e "${STR1}${STR2}" >>${FNM}

fi

cat >>${FNM} <<BBBBBBBB
{0xFFFFFFFF,""},
};
static const struct mess mess1[] =
{
BBBBBBBB

if [ "yes" = ${H1} ]; then

  cat ${HEADER1} | grep "^[ \t]*#define[ \t]*VIDIOC" - | \
     sed -e "s,[ \t]*#define[ \t]*,,;s,[ \t].*$,," - | \
     sed -e "${STR1}${STR2}" >>${FNM}

fi

cat >>${FNM} <<CCCCCCCC
{0xFFFFFFFF,""},
};

k = 0;
while ( mess[k].name[0] )
  {
  if ( wot == mess[k].command )
    {
    SAM("ioctl 0x%08X is %s\n", mess[k].command, &mess[k].name[0]);
    return(0);
    }
  k++;
  }
SAM("ioctl 0x%08X is not in videodev2.h\n", wot );

k = 0;
while ( mess1[k].name[0] )
  {
  if ( wot == mess1[k].command )
    {
    SAM("ioctl 0x%08X is %s (V4L1)\n", mess1[k].command, &mess1[k].name[0]);
    return(0);
    }
  k++;
  }
SAM("ioctl 0x%08X is not in videodev.h\n", wot );
return(-ENOENT);
}
/*****************************************************************************/
int explain_cid( struct easycap *peasycap, __u32 wot )
{
int k;
static const struct mess mess[] =
{
CCCCCCCC

if [ "yes" = ${H2} ]; then

  cat ${HEADER2} | grep "^[ \t]*#define[ \t]*V4L2_CID" - | \
     sed -e "s,[ \t]*#define[ \t]*,,;s,[ \t].*$,," - | \
     sed -e "${STR1}${STR2}" >>${FNM}

fi

cat >>${FNM} <<DDDDDDDD
{0xFFFFFFFF,""},
};

k = 0;
while ( mess[k].name[0] )
  {
  if ( wot == mess[k].command )
    {
    SAM("ioctl 0x%08X is %s\n", mess[k].command, &mess[k].name[0]);
    return(0);
    }
  k++;
  }
SAM("cid 0x%08X is not in videodev2.h\n", wot );
return(-ENOENT);
}
/*****************************************************************************/
DDDDDDDD
exit 0
