#!/bin/bash
#
#
#  softer.sh
#
#
#
declare -i GAIN
declare -i NEWGAIN

if [ ! -z $1 ]; then
  FIXGAIN=$1
  if [ 31 -lt ${FIXGAIN} ]; then FIXGAIN=-1; fi
else
  FIXGAIN=-1
fi

if [ ".`whoami`" != ".root" ]; then
  echo "ERROR: must be run as root"
  exit 1
fi

link=`ls -lart /proc/asound | grep "EasyALSA" - `
if [ ! -z ${link} ]; then
  echo "Please unplug the EasyCAP and then run this script again."
  echo "When the script is finished, plug in the EasyCAP."
  exit 1
fi

DEBUG=""
GAIN=-1
BARS=""
PARAMDIR=/sys/module/easycap/parameters
if [ ! -d ${PARAMDIR} ]; then
  echo "ERROR: cannot find directory /sys/module/easycap/parameters"
  exit 1
fi
if [ -e "${PARAMDIR}/debug" ]; then DEBUG=`cat ${PARAMDIR}/debug`; fi
if [ -e "${PARAMDIR}/gain" ]; then GAIN=`cat ${PARAMDIR}/gain`; fi
if [ -e "${PARAMDIR}/bars" ]; then BARS=`cat ${PARAMDIR}/bars`; fi

if [ 0 -gt ${GAIN} ]; then
  echo "ERROR: could not determine gain"
  exit 1
fi

if [ -z ${BARS} ]; then
  echo "ERROR: could not determine bars"
  exit 1
fi

if [ 0 -ge ${GAIN} ]; then
  echo "Gain is already at minimum"
  exit 1
fi

if [ 0 -le ${FIXGAIN} ]; then
  if [ ${GAIN} -gt ${FIXGAIN} ]; then
    NEWGAIN=${FIXGAIN}
  else
    NEWGAIN=${GAIN}/2
  fi
else
  NEWGAIN=${GAIN}/2
fi

echo "Decreasing gain from ${GAIN} to ${NEWGAIN}"
if [ -z "${DEBUG}" ]; then
  PARAM="gain=${NEWGAIN} bars=${BARS}"
else
  echo "Retaining debug ${DEBUG}"
  PARAM="debug=${DEBUG} gain=${NEWGAIN} bars=${BARS}"
fi

rmmod easycap

#-----------------------------------------------------------------------------
#  WRITE CONFIGURATION FILE FOR modprobe
#-----------------------------------------------------------------------------
if [ ! -z "${PARAM}" ]; then
  if [ -d "/etc/modprobe.d" ]; then
    echo "options easycap ${PARAM}" >./easycap.conf
    if [ -e "/etc/modprobe.d/easycap.conf" ]; then
      diff /etc/modprobe.d/easycap.conf ./easycap.conf >./install.tmp
      if [ -s ./install.tmp ]; then
        echo "overwriting /etc/modprobe.d/easycap.conf"
        cp -p ./easycap.conf /etc/modprobe.d/easycap.conf
      else
        echo "unchanged /etc/modprobe.d/easycap.conf"
      fi
      rm ./install.tmp
    else
      echo "creating /etc/modprobe.d/easycap.conf"
      cp -p ./easycap.conf /etc/modprobe.d/easycap.conf
    fi
  else
    echo "WORRY: Unable to find directory /etc/modprobe.d"
  fi
else
  if [ -e "/etc/modprobe.d/easycap.conf" ]; then
    echo "removing /etc/modprobe.d/easycap.conf"
    rm -fR /etc/modprobe.d/easycap.conf
  fi
fi
#-----------------------------------------------------------------------------
LSMODOUT=`lsmod | grep "^snd_usb_audio " - | sed -e "s, .*$,," - `
if [ "xsnd_usb_audio" = "x${LSMODOUT}" ]; then rmmod snd_usb_audio; fi
LSMODOUT=`lsmod | grep "^snd_usb_audio " - | sed -e "s, .*$,," - `
if [ "xsnd_usb_audio" = "x${LSMODOUT}" ]; then
  echo "ERROR:  snd_usb_audio module cannot be removed"
  exit 1
fi
#-----------------------------------------------------------------------------

modprobe easycap ${PARAM}
exit 0
