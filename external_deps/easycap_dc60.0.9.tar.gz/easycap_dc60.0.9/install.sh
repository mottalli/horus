#!/bin/bash
#
#
#  install.sh
#
#
#  Usage:  ./install.sh
#
#
#  This script has been tested on:   Debian Lenny,  64-bit
#                                    Ubuntu 10.04,  32-bit
#                                    Ubuntu 10.10,  32-bit
#                                    OpenSUSE 11.2, 64-bit
#                                    Fedora 14,     64-bit
#
#-----------------------------------------------------------------------------
#  DEBUG=n    the easycap module is configured at diagnostic level n (0 to 9)
#  GAIN=n     audio gain level n (0 to 31, default is 16)
#  BARS=0     no    testcard bars when incoming video signal is lost
#  BARS=1     shows testcard bars when incoming video signal is lost (default)
#
#  CLIENT=0   the easycap module is independent of the videodev module
#  CLIENT=1   the easycap module registers as a client of the videodev module
#  WFRAME=0   heeds the warning: the frame size ... is larger than 1024 bytes
#  WFRAME=1   overcomes this warning
#  ALSA=0     use Open Sound System
#  ALSA=1     use Advanced Linux Sound Architecture
#-----------------------------------------------------------------------------
DEBUG=0
GAIN=16
BARS=1

CLIENT=1
WFRAME=1
ALSA=1
#-----------------------------------------------------------------------------
#  THE FOLLOWING PARAMETERS ARE USUALLY SET TO
#        OVERWRITE=1
#        SND_USB_AUDIO=0
#  AND SHOULD NOT BE CHANGED WITHOUT GOOD REASON.
#-----------------------------------------------------------------------------
OVERWRITE=1
SND_USB_AUDIO=0
if [ 0 -ne ${SND_USB_AUDIO} ]; then ALSA=0; fi
#-----------------------------------------------------------------------------
#
#
#        *************************************************************
#        *                                                           *
#        *     Ordinarily nothing below here needs to be changed.    *
#        *                                                           *
#        *************************************************************
#
#
#-----------------------------------------------------------------------------
KERNELDIR=""
if [ "x" != "x$1" ]; then KERNELDIR="$1"; fi
#-----------------------------------------------------------------------------
#  CHECK ESSENTIAL COMPONENTS PRESENT
#-----------------------------------------------------------------------------
if [ "x`whoami`" != "xroot" ]; then
  echo "ERROR:  must be run as root"
  exit 1
fi
if [ "x`which gcc`" = "x" ]; then
  echo "ERROR:  cannot find gcc.  Is it installed?"
  exit 1
fi
if [ ! -x `which gcc` ]; then
  echo "ERROR:  cannot execute gcc.  Is it installed correctly?"
  exit 1
fi
if [ "x`which make`" = "x" ]; then
  echo "ERROR:  cannot find make.  Is it installed?"
  exit 1
fi
if [ ! -x `which make` ]; then
  echo "ERROR:  cannot execute make.  Is it installed correctly?"
  exit 1
fi
if [ ! -d "/usr/src" ]; then
  echo "ERROR:  cannot find directory /usr/src"
  echo "        Are the kernel headers installed?"
  exit 1
fi
DEPMODDIR=/lib/modules/`uname -r`
if [ ! -d ${DEPMODDIR} ]; then
  echo "ERROR: directory not found: ${DEPMODDIR}"
  exit 1
fi
SUBMODDIR=kernel/drivers/media/video

#KERNELDIR=/home/rmthomas/KERNEL/linux-new
if [ -z "${KERNELDIR}" ]; then KERNELDIR="${DEPMODDIR}/build"; fi

if [ -z "${KERNELDIR}" ]; then
  echo "ERROR:  Kernel build directory is not set"
  exit 1
fi
if [ ! -d "${KERNELDIR}" ]; then
  echo "ERROR:  cannot find directory ${KERNELDIR}"
  echo "        Are the kernel headers installed correctly?"
  exit 1
fi
echo "kernel directory is ${KERNELDIR}"
#-----------------------------------------------------------------------------
#  CREATE TEMPORARY SUBDIRECTORY FOR CONFIGURATION TESTS
#-----------------------------------------------------------------------------
TAGFILE="./tmpsrc/this_directory_may_be_removed_by_easycap_installer"
if [ -d ./tmpsrc ]; then
  if [ -e "${TAGFILE}" ]; then
    rm -fR ./tmpsrc
  else
    echo "ERROR: directory ./tmpsrc unexpectedly exists."
    echo "       Please remove it after saving any valuable contents."
    exit 1
  fi
fi
mkdir ./tmpsrc
>${TAGFILE}
#-----------------------------------------------------------------------------
#  RECENT VERSIONS OF gcc ACCEPT THE FLAG -Wframe-larger-than=n
#  BUT THIS FLAG IS UNKNOWN TO EARLIER VERSIONS AND GENERATES AN ERROR.
#  SO TRY IT AND SEE.
#-----------------------------------------------------------------------------
if [ 1 -eq ${WFRAME} ]; then
  echo "int main(void) {return 0;}" >./tmpsrc/tmp.c
  sleep 1; touch ./tmpsrc/tmp.c; sleep 1
  1>./tmpsrc/tmp.out 2>./gcc.err \
  gcc -o ./tmpsrc/exe -Wframe-larger-than=8192 ./tmpsrc/tmp.c
  if [ -s "./gcc.err" ]; then
    echo "flag -Wframe-larger-than not needed for this compiler"
    WFRAME=0
  fi
  rm gcc.err
fi
#-----------------------------------------------------------------------------
#  CONSTRUCT A COUPLE OF TEMPORARY MAKEFILES ...
#-----------------------------------------------------------------------------
cat >"./tmpMakefile" <<AAAAAAAA
#
# Temporary top-level makefile.  May be deleted.
#
ALL:	build
build:
	@cd tmpsrc; make
AAAAAAAA

  cat >"./tmpsrc/Makefile" <<BBBBBBBB
#
# Temporary tmpsrc/Makefile.  May be deleted.
#

obj-m     += tmp.o

KERNELDIR ?= ${KERNELDIR}
PWD       := \$(shell pwd)

ccflags-y += -Wall

all:
	\$(MAKE) -C \$(KERNELDIR) M=\$(PWD) modules

BBBBBBBB
#-----------------------------------------------------------------------------
#  ... THEN PERFORM TEST COMPILATIONS AS FOLLOWS
#-----------------------------------------------------------------------------
#  ALSA FUNCTION snd_card_create() REPLACES snd_card_new() IN RECENT KERNELS
#-----------------------------------------------------------------------------
if [ 1 -eq ${ALSA} ]; then
  if [ -e ./tmpsrc/tmp.c ]; then rm ./tmpsrc/tmp.c; fi
  echo "#include <linux/module.h>" >>./tmpsrc/tmp.c
  echo "#include <sound/core.h>" >>./tmpsrc/tmp.c
  echo "int main(void) {struct snd_card *psc;" >>./tmpsrc/tmp.c
  echo "psc=snd_card_new(0,\"\",THIS_MODULE,0);return 0;}" >>./tmpsrc/tmp.c
  sleep 1; touch ./tmpMakefile ./tmpsrc/Makefile ./tmpsrc/tmp.c; sleep 1
  make -f tmpMakefile 1>./tmpsrc/tmp.out 2>./make.err
  if [ \( 0 -ne $? \) -o \( -s "./make.err" \) ]; then
    echo "snd_card_new() will not be used"

    if [ -e ./tmpsrc/tmp.c ]; then rm ./tmpsrc/tmp.c; fi
    echo "#include <linux/module.h>" >>./tmpsrc/tmp.c
    echo "#include <sound/core.h>" >>./tmpsrc/tmp.c
    echo "int main(void) {struct snd_card *psc;" >>./tmpsrc/tmp.c
    echo "snd_card_create(0,\"\",THIS_MODULE,0,&psc);return 0;}" \
                                                          >>./tmpsrc/tmp.c
    sleep 1; touch ./tmpMakefile ./tmpsrc/Makefile ./tmpsrc/tmp.c; sleep 1
    make -f tmpMakefile 1>./tmpsrc/tmp.out 2>./make.err
    if [ \( 0 -ne $? \) -o \( -s "./make.err" \) ]; then
      echo "snd_card_create() will not be used either"
      cat ./make.err
      rm ./make.err
      rm -fR ./tmpMakefile ./tmpsrc
      exit 1
    else
      echo "snd_card_create() will be used"
      EASYCAP_NEEDS_CARD_CREATE="yes"
    fi
  else
    echo "snd_card_new() will be used"
    EASYCAP_NEEDS_CARD_CREATE=""
  fi
  rm -fR make.err
fi
#-----------------------------------------------------------------------------
#  IF the easycap MODULE IS BEING BUILT AS A CLIENT OF THE videodev MODULE
#  FURTHER CONFIGURATION IS NECESSARY.
#-----------------------------------------------------------------------------
if [ 1 -eq ${CLIENT} ]; then
#-----------------------------------------------------------------------------
#  COMPILATION AGAINST VERY RECENT KERNELS REQUIRES INCLUSION OF
#  <v4l2-device.h> AS WELL AS <v4l2-dev.h>.
#-----------------------------------------------------------------------------
  if [ -e ./tmpsrc/tmp.c ]; then rm ./tmpsrc/tmp.c; fi
  echo "#include <media/v4l2-dev.h>" >>./tmpsrc/tmp.c
  echo "#include <media/v4l2-device.h>" >>./tmpsrc/tmp.c
  echo "int main(void) {return 0;}" >>./tmpsrc/tmp.c
  sleep 1; touch ./tmpMakefile ./tmpsrc/Makefile ./tmpsrc/tmp.c; sleep 1
  make -f tmpMakefile 1>./tmpsrc/tmp.out 2>./make.err
  if [ \( 0 -ne $? \) -o \( -s "./make.err" \) ]; then
    echo "<media/v4l2-device.h> will not be included"
    EASYCAP_NEEDS_V4L2_DEVICE_H=""
  else
    echo "<media/v4l2-device.h> will be included"
    EASYCAP_NEEDS_V4L2_DEVICE_H="yes"
  fi
  rm -fR make.err
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#  CHECK THAT video_register_device() IS DEFINED
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  if [ -e ./tmpsrc/tmp.c ]; then rm ./tmpsrc/tmp.c; fi
  echo "#include <media/v4l2-dev.h>" >./tmpsrc/tmp.c
  if [ ! -z "${EASYCAP_NEEDS_V4L2_DEVICE_H}" ]; then
    echo "#include <media/v4l2-device.h>" >>./tmpsrc/tmp.c
  fi
  echo "int main(void) {struct video_device *pv;" >>./tmpsrc/tmp.c
  echo "int r,t,n;" >>./tmpsrc/tmp.c
  echo "pv=NULL;t=0;n=0;" >>./tmpsrc/tmp.c
  echo "r=video_register_device(pv,t,n);return(0);}" >>./tmpsrc/tmp.c
  sleep 1; touch ./tmpMakefile ./tmpsrc/Makefile ./tmpsrc/tmp.c; sleep 1
  make -f tmpMakefile 1>./tmpsrc/tmp.out 2>./make.err
  if [ \( 0 -ne $? \) -o \( -s "./make.err" \) ]; then
    echo "ERROR: video_register_device() cannot be used"
    cat ./tmpsrc/tmp.c
    cat ./make.err
    rm ./make.err
    rm -fR ./tmpMakefile ./tmpsrc
    exit 1
  fi
  rm make.err
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#  IT IS NECESSARY TO ASCERTAIN THE V4L2 TYPE OF video_device.fops, BECAUSE
#  THIS CHANGED IN DECEMBER 2008.
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  if [ -e ./tmpsrc/tmp.c ]; then rm ./tmpsrc/tmp.c; fi
  echo "#include <media/v4l2-dev.h>" >./tmpsrc/tmp.c
  if [ ! -z "${EASYCAP_NEEDS_V4L2_DEVICE_H}" ]; then
    echo "#include <media/v4l2-device.h>" >>./tmpsrc/tmp.c
  fi
  echo "int main(void) {struct video_device v;" >>./tmpsrc/tmp.c
  echo "struct v4l2_file_operations f;" >>./tmpsrc/tmp.c
  echo "v.fops = &f;return(0);}" >>./tmpsrc/tmp.c
  sleep 1; touch ./tmpMakefile ./tmpsrc/Makefile ./tmpsrc/tmp.c; sleep 1
  make -f tmpMakefile 1>./tmpsrc/tmp.out 2>./make.err
  if [ \( 0 -ne $? \) -o \( -s "./make.err" \) ]; then
    echo "struct v4l2_file_operations will not be used"
    rm ./make.err

    rm ./tmpsrc/tmp.c
    echo "#include <media/v4l2-dev.h>" >./tmpsrc/tmp.c
    if [ ! -z "${EASYCAP_NEEDS_V4L2_DEVICE_H}" ]; then
      echo "#include <media/v4l2-device.h>" >>./tmpsrc/tmp.c
    fi
    echo "int main(void) {struct video_device v;" >>./tmpsrc/tmp.c
    echo "struct file_operations f;" >>./tmpsrc/tmp.c
    echo "v.fops = &f;return(0);}" >>./tmpsrc/tmp.c
    sleep 1; touch ./tmpMakefile ./tmpsrc/Makefile ./tmpsrc/tmp.c; sleep 1
    make -f tmpMakefile 1>./tmpsrc/tmp.out 2>./make.err
    if [ -s "./make.err" ]; then
      echo "struct file_operations not appropriate either"
      cat ./make.err
      rm ./make.err
      rm -fR ./tmpMakefile ./tmpsrc
      exit 1
    else
      echo "struct file_operations OK"
      EASYCAP_NEEDS_V4L2_FOPS=""
    fi
  else
    echo "struct v4l2_file_operations OK"
    EASYCAP_NEEDS_V4L2_FOPS="yes"
  fi
  rm ./make.err
#-----------------------------------------------------------------------------
#  UNLOCKED IOCTL IS REQUIRED FOR BUILD AGAINST SOME RECENT KERNELS
#-----------------------------------------------------------------------------
  if [ ! -z ${EASYCAP_NEEDS_V4L2_FOPS} ]; then
    if [ -e ./tmpsrc/tmp.c ]; then rm ./tmpsrc/tmp.c; fi
    echo "#include <media/v4l2-dev.h>" >./tmpsrc/tmp.c
    if [ ! -z "${EASYCAP_NEEDS_V4L2_DEVICE_H}" ]; then
      echo "#include <media/v4l2-device.h>" >>./tmpsrc/tmp.c
    fi
    echo "int main(void) {struct v4l2_file_operations f;" >>./tmpsrc/tmp.c
    echo "f.unlocked_ioctl=NULL;return(0);}" >>./tmpsrc/tmp.c
    sleep 1; touch ./tmpMakefile ./tmpsrc/Makefile ./tmpsrc/tmp.c; sleep 1
    make -f tmpMakefile 1>./tmpsrc/tmp.out 2>./make.err
    if [ \( 0 -ne $? \) -o \( -s "./make.err" \) ]; then
      echo "v4l2_file_operations.ioctl will be used"
      EASYCAP_NEEDS_UNLOCKED_IOCTL=""
    else
      echo "unlocked_ioctl required"
      echo "v4l2_file_operations.unlocked_ioctl will be used"
      EASYCAP_NEEDS_UNLOCKED_IOCTL="yes"
    fi
  fi
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
else
  EASYCAP_NEEDS_V4L2_DEVICE_H=""
  EASYCAP_NEEDS_V4L2_FOPS=""
fi
rm -fR ./tmpMakefile ./tmpsrc
#-----------------------------------------------------------------------------

WORKDIR=`pwd`

if [ ! -d ${WORKDIR} ]; then
  echo "ERROR: directory not found: ${WORKDIR}"
  exit 1
fi
cd ${WORKDIR}
if [ ".${WORKDIR}" != ".`pwd`" ]; then
  echo "ERROR:  cannot access working directory:  ${WORKDIR}"
  exit 1
fi

>/${WORKDIR}/make.out
>/${WORKDIR}/make.err

#-----------------------------------------------------------------------------
#  CREATE src/easycap_ioctlmess.c
#-----------------------------------------------------------------------------
if [ ! -e "./ioctlmess.sh" ]; then
  echo "ERROR:  cannot find file ./ioctlmess.sh"
  exit 1
fi
./ioctlmess.sh
if [ 0 -ne $? ]; then
  echo "ERROR:  script ./ioctlmess.sh failed"
  exit 1
fi
if [ ! -e  "./src/easycap_ioctlmess.c" ]; then
  echo "ERROR:  cannot find file ./src/easycap_ioctlmess.c"
  exit 1
fi
#-----------------------------------------------------------------------------
# CREATE Makefile, src/Makefile AND tools/Makefile FOR BUILD AS NECESSARY
#-----------------------------------------------------------------------------
if [ -e "./Makefile" ]; then
  echo "not overwriting top level Makefile"
else
  echo "-> regenerating top level Makefile"
  cat >"./Makefile" <<CCCCCCCC
#
# Makefile at top level
#

ALL:	build

build:
	@echo "Building"
	@cd src; make
	@cd tools; make

clean:
	@echo "Cleaning"
	@cd src; make clean
	@cd tools; make clean

CCCCCCCC
  chmod ugo+rw ./Makefile
fi
FLAGS=""
if [ 0 -ne ${WFRAME} ]; then FLAGS="${FLAGS} -Wframe-larger-than=8192"; fi
if [ 0 -lt ${DEBUG} ]; then FLAGS="${FLAGS} -DEASYCAP_DEBUG"; fi
if [ 1 -eq ${ALSA} ]; then
  FLAGS="${FLAGS} -DEASYCAP_NEEDS_ALSA"
  if [ ! -z ${EASYCAP_NEEDS_CARD_CREATE} ]; then
    FLAGS="${FLAGS} -DEASYCAP_NEEDS_CARD_CREATE"
  fi
fi
if [ 0 -ne ${SND_USB_AUDIO} ]; then
  FLAGS="${FLAGS} -DEASYCAP_SILENT"
fi
if [ 1 -eq ${CLIENT} ]; then
  FLAGS="${FLAGS} -DEASYCAP_IS_VIDEODEV_CLIENT"
  if [ ! -z ${EASYCAP_NEEDS_V4L2_FOPS} ]; then
    FLAGS="${FLAGS} -DEASYCAP_NEEDS_V4L2_FOPS"
    if [ ! -z ${EASYCAP_NEEDS_UNLOCKED_IOCTL} ]; then
      FLAGS="${FLAGS} -DEASYCAP_NEEDS_UNLOCKED_IOCTL"
    fi
  fi
  if [ ! -z ${EASYCAP_NEEDS_V4L2_DEVICE_H} ]; then
    FLAGS="${FLAGS} -DEASYCAP_NEEDS_V4L2_DEVICE_H"
  fi
fi
#-----------------------------------------------------------------------------
TMPFNM=`mktemp`
if [ -e "./src/Makefile_staging" ]; then
  if [ -z ${FLAGS} ]; then
    cat ./src/Makefile_staging >"${TMPFNM}"
  else
    cat ./src/Makefile_staging | grep -v "ccflags" - | \
                                 grep -v "EXTRA_CFLAGS" - >"${TMPFNM}"
  fi
else
  FLAGS="-Wall ${FLAGS}"
  if [ 1 -eq ${ALSA} ]; then
    ALSAMOD=0
    if [ \( 1 -eq ${ALSAMOD} \) -a \( 1 -eq 2 \) ]; then
      cat >"${TMPFNM}" <<DDDDDDDD
#
# Makefile in source subdirectory
#

obj-m           += easycap.o
obj-m           += easycap-alsa.o

easycap-y       := easycap_main.o easycap_low.o easycap_sound.o
easycap-y       += easycap_ioctl.o easycap_settings.o
easycap-y       += easycap_testcard.o
easycap-y       += easycap_ioctlmess.o

easycap-alsa-y  := easycap_alsa.o

DDDDDDDD
    else
      cat >"${TMPFNM}" <<EEEEEEEE
#
# Makefile in source subdirectory
#

obj-m           += easycap.o

easycap-y       := easycap_main.o easycap_low.o easycap_sound.o
easycap-y       += easycap_ioctl.o easycap_settings.o
easycap-y       += easycap_testcard.o
easycap-y       += easycap_ioctlmess.o

EEEEEEEE
    fi
  else
    cat >"${TMPFNM}" <<FFFFFFFF
#
# Makefile in source subdirectory
#

obj-m           += easycap.o

easycap-y       := easycap_main.o easycap_low.o easycap_sound.o
easycap-y       += easycap_ioctl.o easycap_settings.o
easycap-y       += easycap_testcard.o
easycap-y       += easycap_ioctlmess.o

FFFFFFFF
  fi
fi
if [ ! -z "${FLAGS}" ]; then
  echo "ccflags-y += ${FLAGS}" >>"${TMPFNM}"
fi
cat >>"${TMPFNM}" <<GGGGGGGG

KERNELDIR ?= ${KERNELDIR}
PWD       := \$(shell pwd)

all:
	\$(MAKE) -C \$(KERNELDIR) M=\$(PWD) modules

clean:
	@rm -rf *.o *~ core .depend .*.cmd *.ko *.mod.c .tmp_versions

GGGGGGGG
if [ -e "./src/Makefile" ]; then
  diff ${TMPFNM} ./src/Makefile >./install.tmp
  if [ -s ./install.tmp ]; then
    SUFFIX="_`date +%s`"
    echo "-> saving former src/Makefile as src/Makefile${SUFFIX}"
    mv ./src/Makefile ./src/Makefile${SUFFIX}
    echo "-> regenerating src/Makefile"
    mv ${TMPFNM} ./src/Makefile
  else
    echo "not overwriting src/Makefile"
    rm ${TMPFNM}
  fi
  rm ./install.tmp
else
  echo "---> generating src/Makefile"
  mv ${TMPFNM} ./src/Makefile
fi
chmod ugo+rw ./src/Makefile

#-----------------------------------------------------------------------------
if [ -e "./tools/Makefile" ]; then
  echo "not overwriting tools/Makefile"
else
  echo "---> generating tools/Makefile"
  cat >"./tools/Makefile" <<HHHHHHHH
#
# Makefile in tools subdirectory
#

THISDIR = \`pwd\`

all:	tailer

tailer:	tailer.c
	@\${CC} -o tailer tailer.c
	@mv tailer ..

clean:
	@rm -f *.o tailer ../tailer

HHHHHHHH
  chmod ugo+rw ./tools/Makefile
fi
#-----------------------------------------------------------------------------
if [ ! -e ${WORKDIR}/Makefile ]; then
  echo "ERROR: file not found: ${WORKDIR}/Makefile"
  exit 1
fi
if [ ! -e ${WORKDIR}/src/Makefile ]; then
  echo "ERROR: file not found: ${WORKDIR}/src/Makefile"
  exit 1
fi
if [ ! -e ${WORKDIR}/tools/Makefile ]; then
  echo "ERROR: file not found: ${WORKDIR}/tools/Makefile"
  exit 1
fi

make clean 1>>${WORKDIR}/make.out 2>>${WORKDIR}/make.err

if [ \( 0 -ne $? \) -o \( -s ${WORKDIR}/make.err \) ]; then
  echo "ERROR:  step failed:  make clean"
  cat ${WORKDIR}/make.err
  exit 1
else
  echo "make clean OK"
fi

if [ -e ${WORKDIR}/src/easycap.ko ]; then
  echo "ERROR:  file cannot be deleted: ${WORKDIR}/src/easycap.ko"
  exit 1
fi

make 1>>${WORKDIR}/make.out 2>>${WORKDIR}/make.err

if [ \( 0 -ne $? \) -o \( -s ${WORKDIR}/make.err \) ]; then
  echo "ERROR:  step failed:  make"
  cat ${WORKDIR}/make.err
  exit 1
else
  echo "make OK"
fi
rm ${WORKDIR}/make.out

if [ ! -e ${WORKDIR}/src/easycap.ko ]; then
  echo "ERROR:  cannot make file: ${WORKDIR}/src/easycap.ko"
  exit 1
fi
#-----------------------------------------------------------------------------
#  IF BUILDING AGAINST A NON-RUNNING KERNEL, DO NOT INSTALL IT
#-----------------------------------------------------------------------------
if [ "${KERNELDIR}" != "${DEPMODDIR}/build" ]; then exit 0; fi
#=============================================================================
LSMODOUT=`lsmod | grep "^easycap " - | sed -e "s, .*$,," - `
if [ "xeasycap" = "x${LSMODOUT}" ]; then rmmod easycap; fi
LSMODOUT=`lsmod | grep "^easycap " - | sed -e "s, .*$,," - `
if [ "xeasycap" = "x${LSMODOUT}" ]; then
  echo "ERROR:  easycap module cannot be removed"
  exit 1
fi
#-----------------------------------------------------------------------------
if [ 0 -eq ${SND_USB_AUDIO} ]; then
  LSMODOUT=`lsmod | grep "^snd_usb_audio " - | sed -e "s, .*$,," - `
  if [ "xsnd_usb_audio" = "x${LSMODOUT}" ]; then rmmod snd_usb_audio; fi
  LSMODOUT=`lsmod | grep "^snd_usb_audio " - | sed -e "s, .*$,," - `
  if [ "xsnd_usb_audio" = "x${LSMODOUT}" ]; then
    echo "ERROR:  snd_usb_audio module cannot be removed"
    exit 1
  fi
fi
#-----------------------------------------------------------------------------
LSMODOUT=`lsmod | grep "^stk11xx " - | sed -e "s, .*$,," - `
if [ "xstk11xx" = "x${LSMODOUT}" ]; then rmmod stk11xx; fi
LSMODOUT=`lsmod | grep "^stk11xx " - | sed -e "s, .*$,," - `
if [ "xstk11xx" = "x${LSMODOUT}" ]; then
  echo "ERROR:  stk11xx module cannot be removed"
  exit 1
fi
#-----------------------------------------------------------------------------
mkdir -p ${DEPMODDIR}/${SUBMODDIR}
if [ ! -d ${DEPMODDIR}/${SUBMODDIR} ]; then
  echo "ERROR:  directory not found: ${DEPMODDIR}/${SUBMODDIR}"
  exit 1
fi
#-----------------------------------------------------------------------------
if [ -e ${DEPMODDIR}/${SUBMODDIR}/easycap.ko ]; then
  rm ${DEPMODDIR}/${SUBMODDIR}/easycap.ko
fi
if [ -e ${DEPMODDIR}/${SUBMODDIR}/easycap.ko ]; then
  echo "ERROR:  file cannot be deleted: ${DEPMODDIR}/${SUBMODDIR}/easycap.ko"
  exit 1
fi
#-----------------------------------------------------------------------------
depmod -a -v 1>${WORKDIR}/depmod.out 2>${WORKDIR}/depmod.err
if [ 0 -ne $? ]; then
  echo "ERROR:  step failed:  depmod"
  cat ${WORKDIR}/depmod.err
  exit 1
else
  echo "depmod OK"
fi
#-----------------------------------------------------------------------------
cp -p ${WORKDIR}/src/easycap.ko ${DEPMODDIR}/${SUBMODDIR}
if [ ! -e ${DEPMODDIR}/${SUBMODDIR}/easycap.ko ]; then
  echo "ERROR:  file not found: ${DEPMODDIR}/${SUBMODDIR}/easycap.ko"
  exit 1
else
  echo "copied OK"
fi
#-----------------------------------------------------------------------------
depmod -a -v 1>${WORKDIR}/depmod.out 2>${WORKDIR}/depmod.err
if [ 0 -ne $? ]; then
  echo "ERROR:  step failed:  depmod"
  cat ${WORKDIR}/depmod.err
  exit 1
else
  echo "depmod OK"
fi
rm ${WORKDIR}/depmod.out
#-----------------------------------------------------------------------------
>${WORKDIR}/modprobe.out
>${WORKDIR}/modprobe.err

PARAM=""
if [ 0 -lt ${DEBUG} ]; then PARAM="${PARAM} debug=${DEBUG}"; fi
if [ 0 -le ${GAIN} ]; then PARAM="${PARAM} gain=${GAIN}"; fi
if [ 0 -le ${BARS} ]; then PARAM="${PARAM} bars=${BARS}"; fi
#-----------------------------------------------------------------------------
#  WRITE CONFIGURATION FILE FOR modprobe BEFORE INVOKING modprobe
#-----------------------------------------------------------------------------
if [ -d "/etc/modprobe.d" ]; then
  if [ ! -z "${PARAM}" ]; then
    echo "options easycap ${PARAM}" >./easycap.conf
  fi
  MODPROBE=`which modprobe`
  RMMOD=`which rmmod`
  if [ "x" != "x${MODPROBE}" ]; then
    if [ -x ${MODPROBE} ]; then
      if [ "x" != "x${RMMOD}" ]; then
        if [ -x ${RMMOD} ]; then
          if [ 0 -eq ${SND_USB_AUDIO} ]; then
            CMD="${RMMOD} snd-usb-audio; ${MODPROBE} --ignore-install easycap"
            echo "install easycap ${CMD}" >>./easycap.conf
          fi
        else
          echo "WARNING: ${RMMOD} not executable"
        fi
      else
        echo "WARNING: rmmod not found"
      fi
    else
      echo "WARNING: ${MODPROBE} not executable"
    fi
  else
    echo "WARNING: modprobe not found"
  fi
  if [ -e "/etc/modprobe.d/easycap.conf" ]; then
    diff /etc/modprobe.d/easycap.conf ./easycap.conf >./install.tmp
    if [ -s ./install.tmp ]; then
      if [ 0 -eq ${OVERWRITE} ]; then
        echo "WARNING: not overwriting /etc/modprobe.d/easycap.conf"
        echo "         To force a refresh, delete the existing file"
        echo "         manually and then run ./install.sh again."
      else
        echo "overwriting /etc/modprobe.d/easycap.conf"
        cp -p ./easycap.conf /etc/modprobe.d/easycap.conf
      fi
    else
      echo "unchanged /etc/modprobe.d/easycap.conf"
    fi
    rm ./install.tmp
  else
    echo "creating /etc/modprobe.d/easycap.conf"
    cp -p ./easycap.conf /etc/modprobe.d/easycap.conf
  fi
else
  echo "WARNING: Unable to find directory /etc/modprobe.d"
fi
#-----------------------------------------------------------------------------
1>>${WORKDIR}/modprobe.out 2>>${WORKDIR}/modprobe.err \
modprobe easycap ${PARAM}

if [ 0 -ne $? ]; then
  echo "ERROR:  step failed:  modprobe easycap ${PARAM}"
  cat ${WORKDIR}/modprobe.err
  exit 1
fi
LSMODOUT=`lsmod | grep "^easycap " - | sed -e "s, .*$,," - `
if [ "easycap" != "${LSMODOUT}" ]; then
  echo "ERROR:  easycap module not present"
  exit 1
fi
echo "modprobe OK"
rm ${WORKDIR}/modprobe.out
if [ -e ${WORKDIR}/src/easycap.mod.c ]; then
  rm ${WORKDIR}/src/easycap.mod.c
fi
#-----------------------------------------------------------------------------
#  WRITE CONFIGURATION FILE(S) FOR udev
#-----------------------------------------------------------------------------
UDEV=""
if [ -e "./57-easycap.rules" ]; then
  if [ -d "/etc/udev/rules.d" ]; then
    if [ -e "/etc/udev/rules.d/57-easycap.rules" ]; then
      diff /etc/udev/rules.d/57-easycap.rules ./57-easycap.rules >./install.tmp
      if [ -s ./install.tmp ]; then
        if [ 0 -eq ${OVERWRITE} ]; then
          echo "not overwriting /etc/udev/rules.d/57-easycap.rules"
        else
          echo "overwriting /etc/udev/rules.d/57-easycap.rules"
          cp -p ./57-easycap.rules /etc/udev/rules.d
          if [ -e /etc/udev/rules.d/57-easycap.rules ]; then UDEV="OK"; fi
        fi
      else
        echo "unchanged /etc/udev/rules.d/57-easycap.rules"
        if [ -e /etc/udev/rules.d/57-easycap.rules ]; then UDEV="OK"; fi
      fi
    else
      echo "creating /etc/udev/rules.d/57-easycap.rules"
      cp -p ./57-easycap.rules /etc/udev/rules.d
      if [ -e /etc/udev/rules.d/57-easycap.rules ]; then UDEV="OK"; fi
    fi
  fi
  if [ -d "/lib/udev/rules.d" ]; then
    if [ -e "/lib/udev/rules.d/57-easycap.rules" ]; then
      diff /lib/udev/rules.d/57-easycap.rules ./57-easycap.rules >./install.tmp
      if [ -s ./install.tmp ]; then
        if [ 0 -eq ${OVERWRITE} ]; then
          echo "not overwriting /lib/udev/rules.d/57-easycap.rules"
        else
          echo "overwriting /lib/udev/rules.d/57-easycap.rules"
          cp -p ./57-easycap.rules /lib/udev/rules.d
          if [ -e /lib/udev/rules.d/57-easycap.rules ]; then UDEV="OK"; fi
        fi
      else
        echo "unchanged /lib/udev/rules.d/57-easycap.rules"
        if [ -e /lib/udev/rules.d/57-easycap.rules ]; then UDEV="OK"; fi
      fi
    else
      echo "creating /lib/udev/rules.d/57-easycap.rules"
      cp -p ./57-easycap.rules /lib/udev/rules.d
      if [ -e /lib/udev/rules.d/57-easycap.rules ]; then UDEV="OK"; fi
    fi
  fi
  if [ -z ${UDEV} ]; then
    echo "ERROR: Cannot copy file 57-easycap.rules to"
    echo "       directory /etc/udev/rules.d or directory /lib/udev/rules.d"
  else
    if [ -x /etc/init.d/udev ]; then
      /etc/init.d/udev restart 1>/dev/null 2>&1
    fi
  fi
else
  echo "ERROR: file not found: ./57-easycap.rules"
fi

exit 0
#-------------------------------------EOF-------------------------------------
