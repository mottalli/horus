#!/bin/bash
#
#
#  uninstall.sh
#
#
#  Removes the easycap driver.
#  Tested on Debian only.
#
#
#-----------------------------------------------------------------------------
if [ "x`whoami`" != "xroot" ]; then
  echo "ERROR:  must be run as root"
  exit 1
fi

DEPMODDIR=/lib/modules/`uname -r`
SUBMODDIR=kernel/drivers/media/video

WORKDIR=`pwd`

#-----------------------------------------------------------------------------
LSMODOUT=`lsmod | grep "^easycap " - | sed -e "s, .*$,," - `
if [ "xeasycap" = "x${LSMODOUT}" ]; then rmmod easycap; fi
LSMODOUT=`lsmod | grep "^easycap " - | sed -e "s, .*$,," - `
if [ "xeasycap" = "x${LSMODOUT}" ]; then
  echo "ERROR:  easycap module cannot be removed"
fi
#-----------------------------------------------------------------------------
if [ -e ${DEPMODDIR}/${SUBMODDIR}/easycap.ko ]; then
  rm ${DEPMODDIR}/${SUBMODDIR}/easycap.ko
fi
if [ -e ${DEPMODDIR}/${SUBMODDIR}/easycap.ko ]; then
  echo "ERROR:  file cannot be deleted: ${DEPMODDIR}/${SUBMODDIR}/easycap.ko"
  exit 1
fi
#-----------------------------------------------------------------------------
depmod -a -v 1>${WORKDIR}/depmod.out 2>${WORKDIR}/depmod.err
if [ 0 -ne $? ]; then
  echo "ERROR:  step failed:  depmod"
  cat ${WORKDIR}/depmod.err
  exit 1
fi
echo "depmod OK"
#-----------------------------------------------------------------------------
if [ -e /etc/modprobe.d/easycap.conf ]; then
  rm /etc/modprobe.d/easycap.conf
  if [ -e /etc/modprobe.d/easycap.conf ]; then
    echo "ERROR:  Cannot remove file /etc/modprobe.d/easycap.conf"
  fi
fi
#-----------------------------------------------------------------------------
if [ -e /etc/udev/rules.d/57-easycap.rules ]; then
  rm /etc/udev/rules.d/57-easycap.rules
  if [ -e /etc/udev/rules.d/57-easycap.rules ]; then
    echo "ERROR:  Cannot remove file /etc/udev/rules.d/57-easycap.rules"
  fi
fi
#-----------------------------------------------------------------------------
if [ -e /lib/udev/rules.d/57-easycap.rules ]; then
  rm /lib/udev/rules.d/57-easycap.rules
  if [ -e /lib/udev/rules.d/57-easycap.rules ]; then
    echo "ERROR:  Cannot remove file /lib/udev/rules.d/57-easycap.rules"
  fi
fi
#-----------------------------------------------------------------------------

exit 0

